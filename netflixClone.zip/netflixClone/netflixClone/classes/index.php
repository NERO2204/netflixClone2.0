<?php

require("Movies.php");

$movies=new Movies();
$db=new Database();
$conn=$db->getConn();
$test=$movies->getMovies($conn);

foreach ($test as $movie)
{
    echo $movie->getTitle();
}
