<?php
class Movie
{
    private $id;
    private $title;
    private $videoFileLocation;
    private $description;
    function __construct($id,$title,$videoFileLocation) 
    {
        $this->id = $id;
        $this->title=$title;
        $this->videoFileLocation=$videoFileLocation;
    }
    function getId()
    {
        return $this->id;
    }
    function getTitle()
    {
        return $this->title;
    }
    function getVideoFileLocation()
    {
        return $this->videoFileLocation;
    }
    function getDescription()
    {
        return $this->description;
    }

}