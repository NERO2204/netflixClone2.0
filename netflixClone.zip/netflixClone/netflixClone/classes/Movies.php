<?php
require("db.php");
require("Movie.php");
class Movies
{
    static function getMovies($conn)
    {
        
        $data=new Database();
        $conn=$data->getConn();
        $movies=array();
        
        $sql = "SELECT *
        FROM movie";
        $results = $conn->query($sql);
      

      
        while($data = $results->fetch(PDO::FETCH_ASSOC)){
            $id=$data['id'];
            $title=$data['title'];
            $videoFileLocation=['fileLocation'];

            $movie=new Movie($id,$title,$videoFileLocation);
            array_push($movies,$movie);

        }
        //echo count($movies);

       return $movies;


    }
}